//push
//pop
//shift
//unshift
//splice()
//concat()
//Array.from()
//iterable "hello" [1,2,3]

//new Array()

// what array means?

// is an ordered list of values
// array means data struture that store a list of elements....
// in JS we can define array as a function right?

// isnt array a user defined variable
// a = [1,2,3]

// b = [a, 11,22,22,3,5,11]

// console.log(b[a[0]])
// console.log(b[0][0])

// var fruits = ["banana" ,"apple", "grapes"]
// console.log(fruits.sort())
// console.log(fruits)


// var nums = [1,2,11,23,5]
// console.log(nums.sort())
// nums.sort((a,b) => b - a)
// console.log(nums)

//map , reduce , filter 