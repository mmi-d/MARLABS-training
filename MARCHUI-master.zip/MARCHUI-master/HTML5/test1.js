// let i = 5;


// pre fix ++i
//post fix i++

// console.log(i++)
// a = i++ + 10; //uses and increse
// a = ++i(6) + i++(6) + ++i(8); //increase and use


// console.log(a)
// console.log(i)


 
let i=0;
while (i++ < 5) 
{
     console.log(i)
}


// 1
// 2
// 3
// 4
// 5